__attribute__ ((noreturn))
void writecache(commandargs &cmdargs);
void loadcache(const char *filename, commandargs &cmdargs);
