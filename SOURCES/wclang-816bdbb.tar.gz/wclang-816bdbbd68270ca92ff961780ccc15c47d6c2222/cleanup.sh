#!/bin/sh
git clean -fdx 1>/dev/null