/*
 *  Copyright (C) 2012 Felix Geyer <debfx@fobos.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 or (at your option)
 *  version 3 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef KEEPASSX_TIMEDELTA_H
#define KEEPASSX_TIMEDELTA_H

#include <QMetaType>

class QDateTime;
class TimeDelta;

QDateTime operator+(const QDateTime& dateTime, const TimeDelta& delta);

class TimeDelta
{
public:
    static TimeDelta fromDays(int days);
    static TimeDelta fromMonths(int months);
    static TimeDelta fromYears(int years);

    TimeDelta();
    TimeDelta(int days, int months, int years);

    int getDays() const;
    int getMonths() const;
    int getYears() const;

private:
    int m_days;
    int m_months;
    int m_years;
};

Q_DECLARE_METATYPE(TimeDelta)

#endif // KEEPASSX_TIMEDELTA_H
